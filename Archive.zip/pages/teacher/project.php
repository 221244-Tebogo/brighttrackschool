<?php
include('../../config.php');
include('../../components/header.php');
include('../../components/sidebar.php');
?>

<div class="main-content">
    <h1>Project Management</h1>
    <p>Manage projects assigned to students, track submissions, and grade them.</p>
</div>

<?php
include('../../components/footer.php');
?>
