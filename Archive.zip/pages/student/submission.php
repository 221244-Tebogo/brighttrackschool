<?php
include('../../config.php');
include('../../components/header.php');
include('../../components/sidebar.php');
?>

<div class="main-content">
    <h1>Submit Assignments</h1>
    <p>Interface for students to upload their assignment files.</p>
    <!-- Submission form or related content here -->
</div>

<?php
include('../../components/footer.php');
?>
