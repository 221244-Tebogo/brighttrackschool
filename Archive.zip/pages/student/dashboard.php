<?php
include('../../config.php');
include('../../components/header.php');
include('../../components/sidebar.php');
?>

<div class="main-content">
    <h1>Student Dashboard</h1>
    <!-- Content specific to the student dashboard -->
</div>

<?php
include('../../components/footer.php');
?>
