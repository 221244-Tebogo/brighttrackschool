<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="../../assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
</head>
<body>
  <?php include '../../components/sidebar.php'; ?>
  <script src="../../components/sidebar.js"></script>

  <div style="margin-left: 260px; padding: 20px;">
    <h1>Welcome to the Student Dashboard</h1>
    <!-- Content of your page here -->
  </div>
</body>
</html>
