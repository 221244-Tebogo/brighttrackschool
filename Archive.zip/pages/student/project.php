<?php
include('../../config.php');
include('../../components/header.php');
include('../../components/sidebar.php');
?>

<div class="main-content">
    <h1>Student Projects</h1>
    <p>Details about ongoing projects or assignments.</p>
    <!-- Further project-related content here -->
</div>

<?php
include('../../components/footer.php');
?>
