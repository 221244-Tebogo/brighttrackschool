<link rel="stylesheet" href="../assets/css/style.css">

<footer class="footer">
    <div class="footer-container">
        <div class="footer-content">
            <p>&copy; <?php echo date('Y'); ?> BrightTrack School. All rights reserved.</p>
        </div>
        <div class="go-top">
            <span class="icon-arrow-up"></span>
        </div>
    </div>
</footer>
</body>
</html>
